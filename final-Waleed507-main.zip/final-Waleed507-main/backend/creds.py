#Connection
class Creds:
  conString = 'cis3368spring.cuh6qmddeokd.us-east-1.rds.amazonaws.com'
  userName = 'admin'
  password = 'Ibluemination99$'
  dbname = 'cis3368springdb'